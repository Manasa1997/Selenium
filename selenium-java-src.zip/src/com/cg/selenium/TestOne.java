package com.cg.selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestOne {

	public static void main(String[] args) {
		//Step-1
		System.setProperty("webdriver.chrome.driver","D:\\Top-up\\Selenium\\chromedriver.exe");
		//Step-2
		WebDriver d=new ChromeDriver();
		d.get("http://www.google.com");
		
	}

}
