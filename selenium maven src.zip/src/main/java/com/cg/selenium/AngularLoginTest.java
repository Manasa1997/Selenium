package com.cg.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AngularLoginTest {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","D:\\Top-up\\Selenium\\chromedriver.exe");
		//Step-2
		WebDriver d=new ChromeDriver();
		/*d.get("http://localhost:4200//login");
		WebElement e=d.findElement(By.name("user"));
				e.sendKeys("Manasa");
				WebElement e1=d.findElement(By.name("pass"));
				e1.sendKeys("Madam");

				WebElement e2=d.findElement(By.name("signin"));
				e2.click();*/
				d.get("http://localhost:4200");
				WebElement e=d.findElement(By.name("login"));
				e.click();
			 e=d.findElement(By.name("user"));
						e.sendKeys("Manasa");
					 e=d.findElement(By.name("pass"));
						e.sendKeys("Madam");

						 e=d.findElement(By.name("signin"));
						e.click();
						System.out.println(d.getTitle());
						
						
						

	}

}
