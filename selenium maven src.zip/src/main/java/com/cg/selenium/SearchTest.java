package com.cg.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SearchTest {

	public static void main(String[] args) {
		//Step-1
				System.setProperty("webdriver.chrome.driver","D:\\Top-up\\Selenium\\chromedriver.exe");
				//Step-2
				WebDriver d=new ChromeDriver();
				d.get("http://www.google.com");
			WebElement e=d.findElement(By.name("q"));
			e.sendKeys("mobile phones under 10000");
	e.submit();
	//WebDriverWait wait=new webDriverWait(d,10)
	}
}
